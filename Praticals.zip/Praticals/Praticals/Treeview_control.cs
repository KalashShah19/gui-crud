﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Praticals
{
    public partial class Treeview_control : Form
    {
        public Treeview_control()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            TVInstitute.Nodes.Clear();
        }

        private void btnExpand_Click(object sender, EventArgs e)
        {
            TVInstitute.ExpandAll();
        }

        private void btnCollapse_Click(object sender, EventArgs e)
        {
            TVInstitute.CollapseAll();
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
             int c = TVInstitute.Nodes.Count;
            MessageBox.Show(c.ToString());
        }

        private void btnAddroot_Click(object sender, EventArgs e)
        {
            TVInstitute.Nodes.Add(txtNode.Text);
        }

        private void btnAddchild_Click(object sender, EventArgs e)
        {
            TVInstitute.SelectedNode.Nodes.Add(txtNode.Text);
        }

        private void btnRemoveroot_Click(object sender, EventArgs e)
        {
            TVInstitute.SelectedNode.Remove();
        }

        private void btnRemovechild_Click(object sender, EventArgs e)
        {
            TVInstitute.SelectedNode.Remove();
        }
    }
}
