﻿namespace Praticals
{
    partial class Treeview_control
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TVInstitute = new System.Windows.Forms.TreeView();
            this.btnAddroot = new System.Windows.Forms.Button();
            this.btnAddchild = new System.Windows.Forms.Button();
            this.btnRemoveroot = new System.Windows.Forms.Button();
            this.btnRemovechild = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExpand = new System.Windows.Forms.Button();
            this.btnCollapse = new System.Windows.Forms.Button();
            this.btnCount = new System.Windows.Forms.Button();
            this.txtNode = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // TVInstitute
            // 
            this.TVInstitute.Location = new System.Drawing.Point(12, 12);
            this.TVInstitute.Name = "TVInstitute";
            this.TVInstitute.Size = new System.Drawing.Size(568, 356);
            this.TVInstitute.TabIndex = 0;
            // 
            // btnAddroot
            // 
            this.btnAddroot.Location = new System.Drawing.Point(640, 139);
            this.btnAddroot.Name = "btnAddroot";
            this.btnAddroot.Size = new System.Drawing.Size(94, 29);
            this.btnAddroot.TabIndex = 1;
            this.btnAddroot.Text = "Add Root";
            this.btnAddroot.UseVisualStyleBackColor = true;
            this.btnAddroot.Click += new System.EventHandler(this.btnAddroot_Click);
            // 
            // btnAddchild
            // 
            this.btnAddchild.Location = new System.Drawing.Point(640, 243);
            this.btnAddchild.Name = "btnAddchild";
            this.btnAddchild.Size = new System.Drawing.Size(94, 29);
            this.btnAddchild.TabIndex = 2;
            this.btnAddchild.Text = "Add Child";
            this.btnAddchild.UseVisualStyleBackColor = true;
            this.btnAddchild.Click += new System.EventHandler(this.btnAddchild_Click);
            // 
            // btnRemoveroot
            // 
            this.btnRemoveroot.Location = new System.Drawing.Point(625, 174);
            this.btnRemoveroot.Name = "btnRemoveroot";
            this.btnRemoveroot.Size = new System.Drawing.Size(125, 29);
            this.btnRemoveroot.TabIndex = 3;
            this.btnRemoveroot.Text = "Remove Root";
            this.btnRemoveroot.UseVisualStyleBackColor = true;
            this.btnRemoveroot.Click += new System.EventHandler(this.btnRemoveroot_Click);
            // 
            // btnRemovechild
            // 
            this.btnRemovechild.Location = new System.Drawing.Point(625, 278);
            this.btnRemovechild.Name = "btnRemovechild";
            this.btnRemovechild.Size = new System.Drawing.Size(125, 29);
            this.btnRemovechild.TabIndex = 4;
            this.btnRemovechild.Text = "Remove Child";
            this.btnRemovechild.UseVisualStyleBackColor = true;
            this.btnRemovechild.Click += new System.EventHandler(this.btnRemovechild_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(12, 409);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(94, 29);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExpand
            // 
            this.btnExpand.Location = new System.Drawing.Point(230, 409);
            this.btnExpand.Name = "btnExpand";
            this.btnExpand.Size = new System.Drawing.Size(94, 29);
            this.btnExpand.TabIndex = 6;
            this.btnExpand.Text = "Expand";
            this.btnExpand.UseVisualStyleBackColor = true;
            this.btnExpand.Click += new System.EventHandler(this.btnExpand_Click);
            // 
            // btnCollapse
            // 
            this.btnCollapse.Location = new System.Drawing.Point(435, 409);
            this.btnCollapse.Name = "btnCollapse";
            this.btnCollapse.Size = new System.Drawing.Size(94, 29);
            this.btnCollapse.TabIndex = 7;
            this.btnCollapse.Text = "Collapse";
            this.btnCollapse.UseVisualStyleBackColor = true;
            this.btnCollapse.Click += new System.EventHandler(this.btnCollapse_Click);
            // 
            // btnCount
            // 
            this.btnCount.Location = new System.Drawing.Point(640, 409);
            this.btnCount.Name = "btnCount";
            this.btnCount.Size = new System.Drawing.Size(94, 29);
            this.btnCount.TabIndex = 8;
            this.btnCount.Text = "Count";
            this.btnCount.UseVisualStyleBackColor = true;
            this.btnCount.Click += new System.EventHandler(this.btnCount_Click);
            // 
            // txtNode
            // 
            this.txtNode.Location = new System.Drawing.Point(586, 67);
            this.txtNode.Name = "txtNode";
            this.txtNode.PlaceholderText = "Enter Node here";
            this.txtNode.Size = new System.Drawing.Size(202, 27);
            this.txtNode.TabIndex = 9;
            // 
            // Treeview_control
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtNode);
            this.Controls.Add(this.btnCount);
            this.Controls.Add(this.btnCollapse);
            this.Controls.Add(this.btnExpand);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnRemovechild);
            this.Controls.Add(this.btnRemoveroot);
            this.Controls.Add(this.btnAddchild);
            this.Controls.Add(this.btnAddroot);
            this.Controls.Add(this.TVInstitute);
            this.Name = "Treeview_control";
            this.Text = "Treeview_control";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TreeView TVInstitute;
        private Button btnAddroot;
        private Button btnAddchild;
        private Button btnRemoveroot;
        private Button btnRemovechild;
        private Button btnClear;
        private Button btnExpand;
        private Button btnCollapse;
        private Button btnCount;
        private TextBox txtNode;
    }
}