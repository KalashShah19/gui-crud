﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Praticals
{
    public partial class TextEditor : Form
    {
        public TextEditor()
        {
            InitializeComponent();
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {
            switch (toolStripComboBox1.SelectedItem.ToString())
            {
                case "Microsoft Sans Serif":
                    richTextBox1.Font = new Font("Microsoft Sans Serif", 8);
                    break;
                case "Times New Roman":
                    richTextBox1.Font = new Font("Times New Roman", 8);
                    break;
                default:
                    break;
            }
        }

        private void toolStripComboBox2_Click(object sender, EventArgs e)
        {
            richTextBox1.Font = new Font(richTextBox1.Font.FontFamily, int.Parse(toolStripComboBox2.SelectedItem.ToString()));
        }

        private void TextEditor_Load(object sender, EventArgs e)
        {
            toolStripComboBox1.Text = "Microsoft Sans Serif";
            toolStripComboBox2.Text = 8.ToString();
        }

        private void abToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(colorDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.BackColor = colorDialog1.Color;
            }
        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionColor = colorDialog1.Color;
            }
        }

        private void bToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Bold);
        }
    }
}
