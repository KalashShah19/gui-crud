﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Praticals
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            LVEmployee.View = View.Details;
            LVEmployee.GridLines = true;
            LVEmployee.FullRowSelect = true;
                
            LVEmployee.Columns.Add("Employee ID", 100);
            LVEmployee.Columns.Add("First Name", 100);
            LVEmployee.Columns.Add("Last Name", 100);
            LVEmployee.Columns.Add("City", 100);
            LVEmployee.Columns.Add("Contact no.", 100);
            LVEmployee.Columns.Add("Date of joining", 100);
            LVEmployee.Columns.Add("Salary", 100);

            string[] a1 = new string[7];
            ListViewItem i;
            a1[0] = "096";
            a1[1] = "Pranav";
            a1[2] = "Chaudhari";
            a1[3] = "Silvassa";
            a1[4] = "9824908919";
            a1[5] = "20/01/2021";
            a1[6] = "50000";
            i = new ListViewItem(a1);
            LVEmployee.Items.Add(i);



            string[] a2 = new string[7];
            ListViewItem j;
            a2[0] = "105";
            a2[1] = "Navdeep";
            a2[2] = "Chaudhary";
            a2[3] = "Surat";
            a2[4] = "9876135107";
            a2[5] = "21/09/2021";
            a2[6] = "40000";
            j = new ListViewItem(a2);
            LVEmployee.Items.Add(j);
        }

        private void LVEmployee_MouseDoubleClick(object sender, EventArgs e)
        {
            MessageBox.Show(LVEmployee.SelectedItems[0].SubItems[0].Text + " , "
                + LVEmployee.SelectedItems[0].SubItems[1].Text + " , "
                + LVEmployee.SelectedItems[0].SubItems[2].Text + " , "
                + LVEmployee.SelectedItems[0].SubItems[3].Text + " , "
                + LVEmployee.SelectedItems[0].SubItems[4].Text + " , "
                + LVEmployee.SelectedItems[0].SubItems[5].Text + " , "
                + LVEmployee.SelectedItems[0].SubItems[6].Text);
        }
    }
}
